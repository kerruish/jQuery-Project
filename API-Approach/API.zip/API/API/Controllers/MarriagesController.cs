﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace API.Controllers
{
    public class MarriagesController : ApiController
    {
        public IEnumerable<Marriages_2016> GetMarriages()
        {
            myDBDataContext ctx = new myDBDataContext();
            return ctx.Marriages_2016s;
        }
    }
}
